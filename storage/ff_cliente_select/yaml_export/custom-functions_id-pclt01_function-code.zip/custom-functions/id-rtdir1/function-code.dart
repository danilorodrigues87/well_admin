
  if (items == null || items.isEmpty) {
    return '';
  }
  final pts = <String>[];
  for (final item in items) {
    final lat = item.latitude;
    final lng = item.longitude;
    if (lat == 0.0 && lng == 0.0) {
      continue;
    }
    pts.add('$lat,$lng');
  }
  if (pts.isEmpty) {
    return '';
  }

  final hasOrigin = originLat != null &&
      originLng != null &&
      !(originLat == 0.0 && originLng == 0.0);
  final origin = hasOrigin ? '$originLat,$originLng' : pts.first;
  final dest = pts.last;
  final midPts = hasOrigin
      ? (pts.length > 1 ? pts.sublist(0, pts.length - 1) : <String>[])
      : (pts.length > 2 ? pts.sublist(1, pts.length - 1) : <String>[]);

  if (!hasOrigin && pts.length == 1) {
    return 'https://www.google.com/maps/dir/?api=1&destination=${pts.first}&travelmode=driving';
  }
  if (hasOrigin && pts.length == 1) {
    return 'https://www.google.com/maps/dir/?api=1&origin=$origin&destination=$dest&travelmode=driving';
  }

  var url =
      'https://www.google.com/maps/dir/?api=1&origin=$origin&destination=$dest&travelmode=driving';
  if (midPts.isNotEmpty) {
    url += '&waypoints=${midPts.join('|')}';
  }
  return url;