
  final out = <int>[];
  if (apiJson == null || apiJson is! Map) {
    return out;
  }
  final data = Map<String, dynamic>.from(apiJson)['data'];
  if (data is! Map) {
    return out;
  }
  final items = data['items'];
  if (items is! List) {
    return out;
  }
  for (final raw in items) {
    if (raw is! Map) continue;
    final id = (Map<String, dynamic>.from(raw)['id'] as num?)?.toInt();
    if (id != null && id > 0) out.add(id);
  }
  return out;
