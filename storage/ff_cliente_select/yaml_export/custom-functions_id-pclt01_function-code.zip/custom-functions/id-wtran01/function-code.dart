
  final out = <String>[];
  if (apiJson == null || apiJson is! Map) {
    return out;
  }
  final data = Map<String, dynamic>.from(apiJson)['data'];
  if (data is! Map) {
    return out;
  }
  final items = data['items'];
  if (items is! List) {
    return out;
  }
  for (final raw in items) {
    final s = raw?.toString() ?? '';
    if (s.isNotEmpty) out.add(s);
  }
  return out;
