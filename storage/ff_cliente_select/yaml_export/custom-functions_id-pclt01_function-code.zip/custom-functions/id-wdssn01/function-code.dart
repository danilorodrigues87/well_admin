
  final out = <String>[];
  if (apiJson == null || apiJson is! Map) {
    return out;
  }
  final data = Map<String, dynamic>.from(apiJson)['data'];
  if (data is! Map) {
    return out;
  }
  final items = data['items'];
  if (items is! List) {
    return out;
  }
  for (final raw in items) {
    if (raw is! Map) continue;
    final m = Map<String, dynamic>.from(raw);
    final label = m['label']?.toString() ?? m['nome']?.toString() ?? '';
    if (label.isNotEmpty) out.add(label);
  }
  return out;
