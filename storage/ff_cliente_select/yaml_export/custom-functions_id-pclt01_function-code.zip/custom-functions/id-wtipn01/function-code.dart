
  final out = <String>[];
  if (apiJson == null) {
    return out;
  }
  if (apiJson is! Map) {
    return out;
  }
  final root = Map<String, dynamic>.from(apiJson);
  final data = root['data'];
  if (data is! Map) {
    return out;
  }
  final items = data['items'];
  if (items is! List) {
    return out;
  }
  for (final raw in items) {
    if (raw is! Map) {
      continue;
    }
    final m = Map<String, dynamic>.from(raw);
    final nome = m['nome']?.toString() ?? '';
    if (nome.isEmpty) {
      continue;
    }
    final classe = m['classe_nome']?.toString() ?? '';
    out.add(classe.isNotEmpty ? '$nome ($classe)' : nome);
  }
  return out;
